package de.mahjong.drachenwelt

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.min
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(GameView(this))
    }
}

private data class Tile(val id: Int, val symbol: String, val x: Int, val y: Int, val layer: Int, var alive: Boolean = true)

private class GameView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val symbols = listOf("🌸", "🦋", "🍁", "🎋", "🌺", "🐦", "🐉", "🏮", "❄️", "🌿", "🌼", "☀️", "🍄", "🪷")
    private var level = 1
    private var coins = 1250
    private var tray = mutableListOf<String>()
    private var tiles = mutableListOf<Tile>()
    private var gameOver = false
    private var levelWon = false
    private var message = "Finde gleiche freie Paare"
    private var dragonStage = 0
    private var tileW = 0f
    private var tileH = 0f
    private var boardTop = 0f
    private var scale = 1f

    init { isFocusable = true; newLevel() }

    private fun newLevel() {
        tray.clear(); gameOver = false; levelWon = false
        val pairCount = 8 + (level - 1) * 2
        val chosen = (symbols.shuffled() + symbols.shuffled()).take(pairCount)
        val paired = (chosen + chosen).take(pairCount * 2).shuffled()
        tiles.clear()
        // Compact stacked diamond layout; each pair is guaranteed to exist.
        val coords = mutableListOf<Pair<Int, Int>>()
        val rows = if (level <= 2) listOf(4, 4, 4, 4) else listOf(4, 5, 6, 5, 4)
        rows.forEachIndexed { row, count ->
            val start = (6 - count) / 2
            repeat(count) { col -> coords.add(Pair(start + col, row)) }
        }
        val count = min(coords.size, paired.size)
        for (i in 0 until count) {
            val (x, y) = coords[i]
            tiles.add(Tile(i, paired[i], x, y, if (i % 9 == 0 && level > 1) 1 else 0))
        }
        message = "Finde gleiche freie Paare"
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0 || h <= 0) return
        scale = w / 400f
        c.save(); c.scale(scale, scale)
        val logicalH = h / scale
        drawBackground(c, 400f, logicalH)
        drawHeader(c, logicalH)
        drawBoard(c, logicalH)
        drawTray(c, logicalH)
        drawBottom(c, logicalH)
        if (gameOver) drawOverlay(c, logicalH, "Ablage voll", "Versuche es noch einmal")
        if (levelWon) drawOverlay(c, logicalH, "Level $level geschafft!", "+20 Münzen · Der Drache wächst")
        c.restore()
    }

    private fun drawBackground(c: Canvas, w: Float, h: Float) {
        c.drawColor(Color.rgb(22, 54, 75))
        p.shader = android.graphics.LinearGradient(0f, 0f, 0f, h, Color.rgb(37, 82, 107), Color.rgb(13, 37, 54), android.graphics.Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p); p.shader = null
        // Mountain silhouettes, lake and cherry blossom canopy.
        p.color = Color.rgb(76, 118, 132)
        val path = android.graphics.Path().apply { moveTo(0f, 170f); lineTo(55f, 85f); lineTo(105f, 145f); lineTo(170f, 58f); lineTo(240f, 140f); lineTo(315f, 72f); lineTo(400f, 150f); lineTo(400f, h); lineTo(0f, h); close() }
        c.drawPath(path, p)
        p.color = Color.rgb(36, 103, 124); c.drawRect(0f, 175f, w, h, p)
        p.color = Color.argb(90, 182, 228, 235)
        for (i in 0..6) c.drawLine(0f, 195f + i * 28f, w, 185f + i * 28f, p)
        p.color = Color.rgb(39, 83, 67)
        c.drawOval(-45f, 35f, 95f, 180f, p); c.drawOval(300f, 20f, 450f, 165f, p)
        p.color = Color.rgb(242, 143, 183)
        val rnd = Random(7)
        repeat(40) { c.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * 180f, 1.5f + rnd.nextFloat() * 3f, p) }
    }

    private fun drawHeader(c: Canvas, h: Float) {
        pill(c, 12f, 10f, 104f, 38f, "Level $level", 18f)
        pill(c, 284f, 10f, 104f, 38f, "🪙 $coins", 16f)
        p.color = Color.rgb(255, 211, 108); p.textSize = 12f; p.typeface = Typeface.DEFAULT_BOLD
        c.drawText("DRACHENWELT", 143f, 25f, p)
        val stage = when { level < 10 -> "🥚"; level < 30 -> "🐣"; level < 60 -> "🐲"; else -> "🐉" }
        p.textSize = 27f; c.drawText(stage, 333f, min(h - 110f, 260f), p)
        p.color = Color.WHITE; p.textSize = 11f; p.typeface = Typeface.DEFAULT
        c.drawText(message, 12f, 61f, p)
    }

    private fun drawBoard(c: Canvas, h: Float) {
        val top = 78f
        val availableBottom = h - 168f
        val rows = if ((tiles.maxOfOrNull { it.y } ?: 0) < 4) 4 else 5
        tileW = min(49f, 370f / 6.5f)
        tileH = min(57f, (availableBottom - top) / (rows + 0.3f))
        val totalW = 6 * tileW
        val left = (400f - totalW) / 2f
        boardTop = top
        // lower layers first
        tiles.filter { it.alive }.sortedBy { it.layer }.forEach { t ->
            val x = left + t.x * (tileW * .91f)
            val y = top + t.y * (tileH * .77f) - t.layer * 7f
            val r = RectF(x, y, x + tileW, y + tileH)
            p.color = Color.argb(80, 0, 0, 0); c.drawRoundRect(RectF(r.left + 2, r.top + 4, r.right + 3, r.bottom + 5), 7f, 7f, p)
            p.shader = android.graphics.LinearGradient(r.left, r.top, r.left, r.bottom, Color.rgb(255, 246, 222), Color.rgb(209, 164, 112), android.graphics.Shader.TileMode.CLAMP)
            c.drawRoundRect(r, 7f, 7f, p); p.shader = null
            p.color = Color.rgb(139, 93, 55); p.style = Paint.Style.STROKE; p.strokeWidth = 1f; c.drawRoundRect(r, 7f, 7f, p); p.style = Paint.Style.FILL
            val free = isFree(t)
            p.color = if (free) Color.rgb(68, 52, 40) else Color.rgb(137, 127, 111)
            p.textSize = tileH * .46f; p.textAlign = Paint.Align.CENTER
            c.drawText(t.symbol, r.centerX(), r.centerY() + tileH * .16f, p); p.textAlign = Paint.Align.LEFT
            if (free) { p.color = Color.argb(55, 255, 219, 104); c.drawRoundRect(r, 7f, 7f, p) }
        }
    }

    private fun isFree(t: Tile): Boolean {
        val above = tiles.any { it.alive && it.layer > t.layer && it.x == t.x && it.y == t.y }
        val leftBlocked = tiles.any { it.alive && it.layer == t.layer && it.y == t.y && it.x == t.x - 1 }
        val rightBlocked = tiles.any { it.alive && it.layer == t.layer && it.y == t.y && it.x == t.x + 1 }
        return !above && (!leftBlocked || !rightBlocked)
    }

    private fun drawTray(c: Canvas, h: Float) {
        val y = h - 125f
        p.color = Color.argb(210, 24, 29, 42); c.drawRoundRect(10f, y, 390f, y + 54f, 12f, 12f, p)
        p.color = Color.rgb(255, 211, 108); p.textSize = 12f; c.drawText("ABLAGE", 17f, y - 6f, p)
        repeat(4) { i ->
            val x = 88f + i * 73f
            p.color = Color.rgb(86, 69, 60); c.drawRoundRect(x, y + 6f, x + 61f, y + 48f, 7f, 7f, p)
            if (i < tray.size) { p.color = Color.rgb(255, 246, 222); c.drawRoundRect(x, y + 6f, x + 61f, y + 48f, 7f, 7f, p); p.textSize = 23f; p.textAlign = Paint.Align.CENTER; p.color = Color.DKGRAY; c.drawText(tray[i], x + 30f, y + 34f, p); p.textAlign = Paint.Align.LEFT }
        }
    }

    private fun drawBottom(c: Canvas, h: Float) {
        val y = h - 57f
        val names = listOf("💡 Tipp", "🔀 Mix", "↶ Zurück")
        names.forEachIndexed { i, s ->
            p.color = Color.rgb(78, 48, 54); c.drawRoundRect(12f + i * 130f, y, 128f + i * 130f, y + 38f, 10f, 10f, p)
            p.color = Color.rgb(255, 226, 165); p.textSize = 14f; p.textAlign = Paint.Align.CENTER; c.drawText(s, 70f + i * 130f, y + 24f, p); p.textAlign = Paint.Align.LEFT
        }
    }

    private fun drawOverlay(c: Canvas, h: Float, title: String, subtitle: String) {
        p.color = Color.argb(205, 10, 20, 30); c.drawRect(0f, 0f, 400f, h, p)
        p.color = Color.rgb(69, 43, 54); c.drawRoundRect(28f, h / 2 - 83f, 372f, h / 2 + 83f, 20f, 20f, p)
        p.color = Color.rgb(255, 220, 145); p.textAlign = Paint.Align.CENTER; p.textSize = 24f; p.typeface = Typeface.DEFAULT_BOLD; c.drawText(title, 200f, h / 2 - 25f, p)
        p.textSize = 14f; p.typeface = Typeface.DEFAULT; c.drawText(subtitle, 200f, h / 2 + 5f, p)
        pill(c, 100f, h / 2 + 28f, 200f, 42f, if (levelWon) "Weiter" else "Erneut versuchen", 16f)
        p.textAlign = Paint.Align.LEFT
    }

    private fun pill(c: Canvas, x: Float, y: Float, w: Float, h: Float, text: String, size: Float) {
        p.color = Color.rgb(65, 43, 42); c.drawRoundRect(x, y, x + w, y + h, h / 2, h / 2, p)
        p.color = Color.rgb(255, 214, 124); p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; c.drawRoundRect(x, y, x + w, y + h, h / 2, h / 2, p); p.style = Paint.Style.FILL
        p.color = Color.WHITE; p.textSize = size; p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER; c.drawText(text, x + w / 2, y + h / 2 + size * .34f, p); p.textAlign = Paint.Align.LEFT; p.typeface = Typeface.DEFAULT
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_UP) return true
        val x = e.x / scale; val y = e.y / scale; val h = height / scale
        if (gameOver || levelWon) {
            if (levelWon) { coins += 20; if (level >= 5) { level = 1; message = "Die ersten fünf Level geschafft!" } else level++ }
            newLevel(); return true
        }
        val boardTopLocal = 78f
        val rows = if ((tiles.maxOfOrNull { it.y } ?: 0) < 4) 4 else 5
        val tw = min(49f, 370f / 6.5f); val th = min(57f, (h - 168f - boardTopLocal) / (rows + .3f)); val left = (400f - 6 * tw) / 2f
        val tapped = tiles.filter { it.alive }.asReversed().firstOrNull { t ->
            val tx = left + t.x * (tw * .91f); val ty = boardTopLocal + t.y * (th * .77f) - t.layer * 7f
            x >= tx && x <= tx + tw && y >= ty && y <= ty + th
        }
        if (tapped != null && isFree(tapped)) {
            tapped.alive = false
            tray.add(tapped.symbol)
            val matching = tray.count { it == tapped.symbol } >= 2
            if (matching) { tray.remove(tapped.symbol); tray.remove(tapped.symbol); message = "Paar gefunden!" }
            else message = "Guter Zug!"
            if (tiles.none { it.alive }) { levelWon = true; message = "Level geschafft!" }
            else if (tray.size >= 4) gameOver = true
            invalidate(); return true
        }
        // Bottom controls: functional, lightweight prototype behavior.
        if (y >= h - 60f) {
            when {
                x < 140f -> { val pair = tiles.filter { it.alive && isFree(it) }.groupBy { it.symbol }.values.firstOrNull { it.size >= 2 }; message = if (pair != null) "Tipp: ${pair[0].symbol}" else "Keine freien Paare" }
                x < 270f -> { tiles.filter { it.alive }.forEach { it.symbol.let { s -> } }; tiles.shuffle(); message = "Steine neu gemischt" }
                else -> { if (tray.isNotEmpty()) { val last = tray.removeAt(tray.lastIndex); tiles.firstOrNull { !it.alive && it.symbol == last }?.alive = true; message = "Letzter Zug zurück" } }
            }
            invalidate(); return true
        }
        return true
    }
}
