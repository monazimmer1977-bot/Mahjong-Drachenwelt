plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.mahjong.drachenwelt"
    compileSdk = 35
    defaultConfig {
        applicationId = "de.mahjong.drachenwelt"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
